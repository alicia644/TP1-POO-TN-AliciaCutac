package ar.org.centro8.curso.java.Alicia_Cutac_Tp1_Tn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AliciaCutacTp1TnApplication {

	public static void main(String[] args) {
		SpringApplication.run(AliciaCutacTp1TnApplication.class, args);
	}

}
