package ar.org.centro8.curso.java.Alicia_Cutac_Tp1_Tn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AliciaCutacTp1TnApplicationTests {

	@Test
	void contextLoads() {
	}

}
